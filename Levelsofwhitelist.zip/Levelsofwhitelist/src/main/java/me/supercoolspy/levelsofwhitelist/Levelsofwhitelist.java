package me.supercoolspy.levelsofwhitelist;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.ChatColor;
import  org.bukkit.*;
public final class Levelsofwhitelist extends JavaPlugin {

    @Override
    public void onEnable() {
        // Plugin startup logic
        this.saveDefaultConfig();
        FileConfiguration config = this.getConfig();
        System.out.println(ChatColor.GREEN + "Enabling Levels of whitelist");
        if(config.getBoolean("WhitelistEnabled")) {
            getServer().getPluginManager().registerEvents(new whitelistLevel1(), this);
        }
        else {
            config.addDefault("WhitelistEnabled", true);
            config.options().copyDefaults(true);
        }
        saveConfig();
    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
        System.out.println(ChatColor.RED + "Bye see you soon");
    }
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

        return  false;
    }
}
