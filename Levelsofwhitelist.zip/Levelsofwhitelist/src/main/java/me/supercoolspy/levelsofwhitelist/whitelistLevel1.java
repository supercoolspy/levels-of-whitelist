package me.supercoolspy.levelsofwhitelist;

import org.bukkit.Server;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.ChatColor;
public class whitelistLevel1 implements Listener {
    @EventHandler
    public void join(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (player.hasPermission("LevelsOfWhitelist.join.1") || player.hasPermission("LevelsOfWhitelist.join.bypass") || player.hasPermission("LevelsOfWhitelist.join.2"))
            player.sendMessage(ChatColor.AQUA + "Welcome to the PCDS alpha server");
        else
            player.kickPlayer(ChatColor.RED + "You Are Not Allowed to Join the Server to Join the Server\n Fill Out a Form https://bit.ly/applyforserver");
    }
}
